import Maharashtra from './Maharashtra';
export default Maharashtra;
