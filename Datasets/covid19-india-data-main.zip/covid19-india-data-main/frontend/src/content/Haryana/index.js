import Haryana from './Haryana';
export default Haryana;
