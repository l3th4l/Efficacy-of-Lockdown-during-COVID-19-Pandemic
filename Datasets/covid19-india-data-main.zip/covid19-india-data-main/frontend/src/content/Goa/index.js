import Goa from './Goa';
export default Goa;
