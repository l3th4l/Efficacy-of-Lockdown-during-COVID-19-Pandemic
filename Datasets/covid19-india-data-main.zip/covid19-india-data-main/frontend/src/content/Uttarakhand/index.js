import Uttarakhand from './Uttarakhand';
export default Uttarakhand;
