import Telangana from './Telangana';
export default Telangana;
