import Kerala from './Kerala';
export default Kerala;
