import Punjab from './Punjab';
export default Punjab;
