import Delhi from './Delhi';
export default Delhi;
