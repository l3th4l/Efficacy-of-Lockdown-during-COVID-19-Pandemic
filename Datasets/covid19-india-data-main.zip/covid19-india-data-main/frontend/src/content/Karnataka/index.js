import Karnataka from './Karnataka';
export default Karnataka;
