import DataAccessPage from './DataAccessPage';
export default DataAccessPage;
