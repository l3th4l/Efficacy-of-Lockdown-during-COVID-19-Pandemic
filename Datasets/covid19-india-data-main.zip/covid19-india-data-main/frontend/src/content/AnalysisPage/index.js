import AnalysisPage from './AnalysisPage';
export default AnalysisPage;
