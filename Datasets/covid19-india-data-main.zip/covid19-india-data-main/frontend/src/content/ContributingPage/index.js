import ContributingPage from './ContributingPage';
export default ContributingPage;
