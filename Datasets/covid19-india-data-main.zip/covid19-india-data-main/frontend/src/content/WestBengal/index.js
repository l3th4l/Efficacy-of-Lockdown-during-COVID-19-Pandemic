import WestBengal from './WestBengal';
export default WestBengal;
