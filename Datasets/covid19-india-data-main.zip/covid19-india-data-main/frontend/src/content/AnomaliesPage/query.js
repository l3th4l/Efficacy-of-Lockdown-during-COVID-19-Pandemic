// import React from 'react';
// import { Link } from 'carbon-components-react';

const QUERIES = [];

export { QUERIES };
