import AnomaliesPage from './AnomaliesPage';
export default AnomaliesPage;
