class UnprocessedBulletinException(Exception):
    """ Raised when a bulletin fails certain validity checks (ex. MH) """
    pass